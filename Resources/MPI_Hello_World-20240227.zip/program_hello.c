/* Hello world program */
#include <stdio.h>

int main(void)
{
  printf("\n Hello, world!\n");

  return 0;
}



