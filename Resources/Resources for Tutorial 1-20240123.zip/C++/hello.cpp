#include <iostream>
using namespace std;

int main () {
	
	char name[50];
    cout << "Please enter your name: ";
    cin >> name;
	
	cout << "Hello " << name << "! Welcome to ID5130!" << endl;	
	return 0;
}
